import numpy as np

path = None
C_limits = None
std = 0.0
t0 = 0
par_process = None  # empty global variable to fill with parallel class in main_rans.py
work_function = None
Truth = None
Strain = None
case = None
prior_interpolator = None

norm_order = 2               # options: 1 - max, 2 - second norm

